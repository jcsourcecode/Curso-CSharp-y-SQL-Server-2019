﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

using CapaEntidades;

namespace CapaDatos
{
    public class D_Ciudades
    {
        readonly SqlConnection conectar = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexion"].ConnectionString);

        public DataTable MostrarRegistros()
        {
            DataTable DtResultado = new DataTable();
            SqlCommand SqlCmd = new SqlCommand("spmostrar_ciudades", conectar)
            {
                CommandType = CommandType.StoredProcedure
            };

            SqlDataAdapter SqlDat = new SqlDataAdapter(SqlCmd);
            SqlDat.Fill(DtResultado);

            return DtResultado;
        }

        public void InsertarRegistros(E_Ciudades ciudades)
        {
            SqlCommand SqlCmd = new SqlCommand("spinsertar_ciudades", conectar)
            {
                CommandType = CommandType.StoredProcedure
            };

            conectar.Open();

            SqlCmd.Parameters.AddWithValue("@descripcion", ciudades.Descripcion);

            SqlCmd.ExecuteNonQuery();

            conectar.Close();
        }

        public void EditarRegistros(E_Ciudades cuidades)
        {
            SqlCommand SqlCmd = new SqlCommand("speditar_ciudades", conectar)
            {
                CommandType = CommandType.StoredProcedure
            };

            conectar.Open();

            SqlCmd.Parameters.AddWithValue("@idciudades", cuidades.IdCiudades);
            SqlCmd.Parameters.AddWithValue("@descripcion", cuidades.Descripcion);

            SqlCmd.ExecuteNonQuery();

            conectar.Close();
        }

        public void EliminarRegistros(E_Ciudades ciudades)
        {
            SqlCommand SqlCmd = new SqlCommand("speliminar_ciudades", conectar)
            {
                CommandType = CommandType.StoredProcedure
            };

            conectar.Open();

            SqlCmd.Parameters.AddWithValue("@idciudades", ciudades.IdCiudades);

            SqlCmd.ExecuteNonQuery();

            conectar.Close();
        }
    }
}
