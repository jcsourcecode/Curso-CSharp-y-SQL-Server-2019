﻿using CapaEntidades;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class D_Profesionales
    {
        readonly SqlConnection conectar = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexion"].ConnectionString);

        public DataTable MostrarRegistros()
        {
            DataTable DtResultado = new DataTable();
            SqlCommand SqlCmd = new SqlCommand("spmostrar_profesionales", conectar)
            {
                CommandType = CommandType.StoredProcedure
            };

            SqlDataAdapter SqlDat = new SqlDataAdapter(SqlCmd);
            SqlDat.Fill(DtResultado);

            return DtResultado;
        }

        public DataTable BuscarRegistros(string textobuscar)
        {
            DataTable DtResultado = new DataTable();
            SqlCommand SqlCmd = new SqlCommand("spbuscar_profesionales", conectar)
            {
                CommandType = CommandType.StoredProcedure
            };

            SqlCmd.Parameters.AddWithValue("@textobuscar", textobuscar);

            SqlDataAdapter SqlDat = new SqlDataAdapter(SqlCmd);
            SqlDat.Fill(DtResultado);

            return DtResultado;
        }

        public void InsertarRegistros(E_Profesionales profesionales)
        {
            SqlCommand SqlCmd = new SqlCommand("spinsertar_profesionales", conectar)
            {
                CommandType = CommandType.StoredProcedure
            };

            conectar.Open();

            SqlCmd.Parameters.AddWithValue("@ciprofesional", profesionales.CIProfesional);
            SqlCmd.Parameters.AddWithValue("@nombres", profesionales.Nombres);
            SqlCmd.Parameters.AddWithValue("@apellidos", profesionales.Apellidos);
            SqlCmd.Parameters.AddWithValue("@direccion", profesionales.Direccion);
            SqlCmd.Parameters.AddWithValue("@telefono", profesionales.Telefono);
            SqlCmd.Parameters.AddWithValue("@correo", profesionales.Correo);
            SqlCmd.Parameters.AddWithValue("@idciudades", profesionales.IdCiudades);

            SqlCmd.ExecuteNonQuery();

            conectar.Close();
        }

        public void EditarRegistros(E_Profesionales profesionales)
        {
            SqlCommand SqlCmd = new SqlCommand("speditar_profesionales", conectar)
            {
                CommandType = CommandType.StoredProcedure
            };

            conectar.Open();

            SqlCmd.Parameters.AddWithValue("@idprofesionales", profesionales.IdProfesionales);
            SqlCmd.Parameters.AddWithValue("@ciprofesional", profesionales.CIProfesional);
            SqlCmd.Parameters.AddWithValue("@nombres", profesionales.Nombres);
            SqlCmd.Parameters.AddWithValue("@apellidos", profesionales.Apellidos);
            SqlCmd.Parameters.AddWithValue("@direccion", profesionales.Direccion);
            SqlCmd.Parameters.AddWithValue("@telefono", profesionales.Telefono);
            SqlCmd.Parameters.AddWithValue("@correo", profesionales.Correo);
            SqlCmd.Parameters.AddWithValue("@idciudades", profesionales.IdCiudades);

            SqlCmd.ExecuteNonQuery();

            conectar.Close();
        }

        public void EliminarRegistros(E_Profesionales profesionales)
        {
            SqlCommand SqlCmd = new SqlCommand("speliminar_profesionales", conectar)
            {
                CommandType = CommandType.StoredProcedure
            };

            conectar.Open();

            SqlCmd.Parameters.AddWithValue("@idprofesionales", profesionales.IdProfesionales);

            SqlCmd.ExecuteNonQuery();

            conectar.Close();
        }
    }
}
