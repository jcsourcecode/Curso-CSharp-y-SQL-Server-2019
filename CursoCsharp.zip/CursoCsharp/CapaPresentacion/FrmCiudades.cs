﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using CapaEntidades;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class FrmCiudades : Form
    {
        private bool Editar = false;
        readonly E_Ciudades ObjEntidad = new E_Ciudades();
        readonly N_Ciudades ObjNegocio = new N_Ciudades();

        public FrmCiudades()
        {
            InitializeComponent();
        }

        private void MensajeConfirmacion(string Mensaje)
        {
            MessageBox.Show(Mensaje, "Curso CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MensajeError(string Mensaje)
        {
            MessageBox.Show(Mensaje, "Curso CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public void MostrarRegistros()
        {
            Data_Listado.DataSource = N_Ciudades.MostrarRegistros();
        }

        private void LimpiarCajas()
        {
            Editar = false;
            Txt_Codigo.Text = "";
            Txt_Descripcion.Text = "";
            Txt_Descripcion.Focus();
        }

        private void FrmCiudades_Load(object sender, EventArgs e)
        {
            MostrarRegistros();
        }

        private void Pb_Cerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Btn_Nuevo_Click(object sender, EventArgs e)
        {
            LimpiarCajas();
        }

        private void Btn_Editar_Click(object sender, EventArgs e)
        {
            if (Data_Listado.SelectedRows.Count>0)
            {
                Editar = true;
                Txt_Codigo.Text = Data_Listado.CurrentRow.Cells[0].Value.ToString();
                Txt_Descripcion.Text = Data_Listado.CurrentRow.Cells[1].Value.ToString();
            }
            else
            {
                MensajeError("Seleccione una fila Primero");
            }
        }

        private void Btn_Eliminar_Click(object sender, EventArgs e)
        {
            if (Data_Listado.SelectedRows.Count>0)
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Realmente desea eliminar el Registro?", "Curso CSharp", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (opcion==DialogResult.OK)
                {
                    ObjEntidad.IdCiudades = Convert.ToInt32(Data_Listado.CurrentRow.Cells[0].Value.ToString());
                    ObjNegocio.EliminarRegistros(ObjEntidad);

                    MensajeConfirmacion("Se eliminó correctamente el registro");

                    MostrarRegistros();
                }
            }
            else
            {
                MensajeError("Seleccione Primero una Fila a Eliminar");
            }
        }

        private void Btn_Guardar_Click(object sender, EventArgs e)
        {
            if (Editar==false)
            {
                try
                {
                    ObjEntidad.Descripcion = Txt_Descripcion.Text.ToUpper();

                    ObjNegocio.InsertarRegistros(ObjEntidad);

                    MensajeConfirmacion("Se insertó correctamente");
                    MostrarRegistros();
                    LimpiarCajas();
                }
                catch (Exception)
                {
                    MensajeError("No se pudo insertar el registro");
                }
            }
            if (Editar==true)
            {
                try
                {
                    ObjEntidad.IdCiudades = Convert.ToInt32(Txt_Codigo.Text);
                    ObjEntidad.Descripcion = Txt_Descripcion.Text.ToUpper();

                    ObjNegocio.EditarRegistros(ObjEntidad);

                    MensajeConfirmacion("Se editó correctamente el registro");
                    MostrarRegistros();
                    LimpiarCajas();
                }
                catch (Exception)
                {
                    MensajeError("No se pudo modificar el registro");
                }
            }
        }
    }
}
