﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using CapaEntidades;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class FrmListadoProfesionales : Form
    {
        readonly E_Profesionales ObjEntidad = new E_Profesionales();
        readonly N_Profesionales ObjNegocio = new N_Profesionales();

        public FrmListadoProfesionales()
        {
            InitializeComponent();
        }

        private void MensajeConfirmacion(string mensaje)
        {
            MessageBox.Show(mensaje, "Curso CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Curso CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public void AccionesTabla()
        {
            DataListado.Columns[0].Visible = false;
            DataListado.Columns[7].Visible = false;

            DataListado.Columns[1].HeaderText = "Nº Cédula";
            DataListado.Columns[2].HeaderText = "Nombres";
            DataListado.Columns[3].HeaderText = "Apellidos";
            DataListado.Columns[4].HeaderText = "Dirección";
            DataListado.Columns[5].HeaderText = "Teléfono";
            DataListado.Columns[6].HeaderText = "Correo";
        }

        public void MostrarRegistro()
        {
            DataListado.DataSource = N_Profesionales.MostrarRegistros();
            AccionesTabla();
        }

        public void BuscarRegistros()
        {
            DataListado.DataSource = N_Profesionales.BuscarRegistros(TxtBuscar.Text);
        }

        private void ActualizarDatos(object sender, FormClosedEventArgs e)
        {
            MostrarRegistro();
        }

        private void FrmListadoProfesionales_Load(object sender, EventArgs e)
        {
            MostrarRegistro();
        }

        private void PbCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            FrmProfesionales nuevoregistro = new FrmProfesionales();
            nuevoregistro.FormClosed += new FormClosedEventHandler(ActualizarDatos);
            nuevoregistro.ShowDialog();
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            FrmProfesionales editarregistros = new FrmProfesionales();
            editarregistros.FormClosed += new FormClosedEventHandler(ActualizarDatos);
            if (DataListado.SelectedRows.Count > 0)
            {
                Program.Evento = 1;
                editarregistros.TxtCodigo.Text = DataListado.CurrentRow.Cells[0].Value.ToString();
                editarregistros.TxtCIProfesional.Text = DataListado.CurrentRow.Cells[1].Value.ToString();
                editarregistros.TxtNombres.Text = DataListado.CurrentRow.Cells[2].Value.ToString();
                editarregistros.TxtApellidos.Text = DataListado.CurrentRow.Cells[3].Value.ToString();
                editarregistros.TxtDireccion.Text = DataListado.CurrentRow.Cells[4].Value.ToString();
                editarregistros.TxtTelefono.Text = DataListado.CurrentRow.Cells[5].Value.ToString();
                editarregistros.TxtCorreo.Text = DataListado.CurrentRow.Cells[6].Value.ToString();
                editarregistros.CbCiudad.SelectedValue = DataListado.CurrentRow.Cells[7].Value.ToString();
                editarregistros.ShowDialog();
            }
            else
            {
                MensajeError("Seleccione la Fila a Editar");
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (DataListado.SelectedRows.Count > 0)
            {
                DialogResult opcion;
                opcion = MessageBox.Show("Realmente desea Eliminar el Registro?", "Curso CSharp", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (opcion == DialogResult.OK)
                {
                    ObjEntidad.IdProfesionales = Convert.ToInt32(DataListado.CurrentRow.Cells[0].Value.ToString());

                    ObjNegocio.EliminarRegistros(ObjEntidad);

                    MensajeConfirmacion("Se Eliminó Correctamente");
                    MostrarRegistro();
                }
            }
            else
            {
                MensajeError("Seleccione el Regiistro a Eliminar");
            }
        }

        private void TxtBuscar_TextChanged(object sender, EventArgs e)
        {
            BuscarRegistros();
        }
    }
}
