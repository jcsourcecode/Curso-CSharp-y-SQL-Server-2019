﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using CapaEntidades;
using CapaNegocios;

namespace CapaPresentacion
{
    public partial class FrmProfesionales : Form
    {
        readonly E_Profesionales ObjEntidad = new E_Profesionales();
        readonly N_Profesionales ObjNegocios = new N_Profesionales();

        public FrmProfesionales()
        {
            InitializeComponent();
            LlenarComboBox();
        }

        private void MensajeConfirmacion(string mensaje)
        {
            MessageBox.Show(mensaje, "Curso CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Curso CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void LimpiarCajas()
        {
            TxtCodigo.Text = "";
            TxtCIProfesional.Text = "";
            TxtNombres.Text = "";
            TxtApellidos.Text = "";
            TxtDireccion.Text = "";
            TxtTelefono.Text = "";
            TxtCorreo.Text = "";
            TxtCodigo.Focus();
        }

        private void LlenarComboBox()
        {
            CbCiudad.DataSource = N_Ciudades.MostrarRegistros();
            CbCiudad.ValueMember = "idciudades";
            CbCiudad.DisplayMember = "descripcion";
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (TxtCIProfesional.Text.Trim() != "")
            {
                if (Program.Evento == 0)
                {
                    try
                    {
                        ObjEntidad.CIProfesional = TxtCIProfesional.Text.ToUpper();
                        ObjEntidad.Nombres = TxtNombres.Text.ToUpper();
                        ObjEntidad.Apellidos = TxtApellidos.Text.ToUpper();
                        ObjEntidad.Direccion = TxtDireccion.Text.ToUpper();
                        ObjEntidad.Telefono = TxtTelefono.Text.ToUpper();
                        ObjEntidad.Correo = TxtCorreo.Text.ToUpper();
                        ObjEntidad.IdCiudades = Convert.ToInt32(CbCiudad.SelectedValue);

                        ObjNegocios.InsertarRegistros(ObjEntidad);
                        MensajeConfirmacion("Se Insertó Correctamente");
                        Program.Evento = 0;
                        LimpiarCajas();
                        Close();
                    }
                    catch (Exception)
                    {
                        MensajeError("No se Pudo Insertar el Registro");
                    }
                }
                else
                {
                    try
                    {
                        ObjEntidad.IdProfesionales = Convert.ToInt32(TxtCodigo.Text.ToUpper());
                        ObjEntidad.CIProfesional = TxtCIProfesional.Text.ToUpper();
                        ObjEntidad.Nombres = TxtNombres.Text.ToUpper();
                        ObjEntidad.Apellidos = TxtApellidos.Text.ToUpper();
                        ObjEntidad.Direccion = TxtDireccion.Text.ToUpper();
                        ObjEntidad.Telefono = TxtTelefono.Text.ToUpper();
                        ObjEntidad.Correo = TxtCorreo.Text.ToUpper();
                        ObjEntidad.IdCiudades = Convert.ToInt32(CbCiudad.SelectedValue);

                        ObjNegocios.EditarRegistros(ObjEntidad);

                        MensajeConfirmacion("Se Modificó Correctamente");
                        Program.Evento = 0;
                        LimpiarCajas();
                        Close();
                    }
                    catch (Exception)
                    {
                        MensajeError("No se Pudo Editar el Registro");
                    }

                }
            }
            else
            {
                MensajeError("Llene los Campos correspondientes para Guardar el Registro");
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarCajas();
        }

        private void PbCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
