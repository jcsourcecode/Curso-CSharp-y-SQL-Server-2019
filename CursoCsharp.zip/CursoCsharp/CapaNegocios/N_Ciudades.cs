﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

using CapaDatos;
using CapaEntidades;

namespace CapaNegocios
{
    public class N_Ciudades
    {
        readonly D_Ciudades ObjCiudades = new D_Ciudades();

        public static DataTable MostrarRegistros()
        {
            return new D_Ciudades().MostrarRegistros();
        }

        public void InsertarRegistros(E_Ciudades ciudades)
        {
            ObjCiudades.InsertarRegistros(ciudades);
        }

        public void EditarRegistros(E_Ciudades ciudades)
        {
            ObjCiudades.EditarRegistros(ciudades);
        }

        public void EliminarRegistros(E_Ciudades ciudades)
        {
            ObjCiudades.EliminarRegistros(ciudades);
        }
    }
}
