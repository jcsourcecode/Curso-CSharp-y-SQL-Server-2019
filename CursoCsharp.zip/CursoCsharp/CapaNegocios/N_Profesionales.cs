﻿using System.Data;

using CapaDatos;
using CapaEntidades;

namespace CapaNegocios
{
    public class N_Profesionales
    {
        readonly D_Profesionales ObjProfesionales = new D_Profesionales();

        public static DataTable MostrarRegistros()
        {
            return new D_Profesionales().MostrarRegistros();
        }

        public static DataTable BuscarRegistros(string textobuscar)
        {
            return new D_Profesionales().BuscarRegistros(textobuscar);
        }

        public void InsertarRegistros(E_Profesionales profesionales)
        {
            ObjProfesionales.InsertarRegistros(profesionales);
        }

        public void EditarRegistros(E_Profesionales profesionales)
        {
            ObjProfesionales.EditarRegistros(profesionales);
        }

        public void EliminarRegistros(E_Profesionales profesionales)
        {
            ObjProfesionales.EliminarRegistros(profesionales);
        }
    }
}
