﻿namespace CapaEntidades
{
    public class E_Profesionales
    {
        public int IdProfesionales { get; set; }
        public string CIProfesional { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public int IdCiudades { get; set; }
    }
}
